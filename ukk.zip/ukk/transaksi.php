<?php
include 'config.php';

if (isset($_POST['simpan'])) {
    $PelangganID = $_POST['PelangganID'];
    $TanggalPenjualan = date('Y-m-d');
    $ProdukID = $_POST['ProdukID'];
    $JumlahProduk = $_POST['JumlahProduk'];

    $q_produk = mysqli_query($conn, "SELECT Harga FROM kasir_produk WHERE ProdukID = '$ProdukID'");
    $produk = mysqli_fetch_assoc($q_produk);
    $Harga = $produk['Harga'];

    $Subtotal = $Harga * $JumlahProduk;
    $TotalHarga = $Subtotal;

    mysqli_query($conn, "INSERT INTO kasir_penjualan (TanggalPenjualan, TotalHarga, PelangganID) VALUES ('$TanggalPenjualan', '$TotalHarga', '$PelangganID')");
    
    $PenjualanID = mysqli_insert_id($conn);

    mysqli_query($conn, "INSERT INTO kasir_detailpenjualan (PenjualanID, ProdukID, JumlahProduk, Subtotal) VALUES ('$PenjualanID', '$ProdukID', '$JumlahProduk', '$Subtotal')");

    echo "<script>alert('Transaksi Berjaya Disimpan!'); window.location='pembelian.php';</script>";
}

$data_pelanggan = mysqli_query($conn, "SELECT * FROM pelanggann");
$data_produk = mysqli_query($conn, "SELECT * FROM produkk");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Transaksi Pembelian</ti tle>
</head>
<body>
    <h2>Form Transaksi Pembelian</h2>
    <a href="index.php">Kembali ke Dashboard</a>
    <hr>

    <form method="POST">
        <label>Pilih Pembeli:</label><br>
        <select name="PelangganID" required>
            <option value="">-- Pilih Pembeli --</option>
            <?php while ($p = mysqli_fetch_assoc($data_pelanggan)) : ?>
                <option value="<?= $p['PelangganID']; ?>"><?= $p['NamaPelanggan']; ?></option>
            <?php endwhile; ?>
        </select>
        <br><br>

        <label>Pilih Produk:</label><br>
        <select name="ProdukID" required>
            <option value="">-- Pilih Produk --</option>
            <?php while ($pr = mysqli_fetch_assoc($data_produk)) : ?>
                <option value="<?= $pr['ProdukID']; ?>"><?= $pr['NamaProduk']; ?> (Stok: <?= $pr['Stok']; ?>)</option>
            <?php endwhile; ?>
        </select>
        <br><br>

        <label>Jumlah Produk:</label><br>
        <input type="number" name="JumlahProduk" value="1" min="1" required>
        <br><br>

        <button type="submit" name="simpan">Simpan Transaksi</button>
    </form>
</body>
</html>